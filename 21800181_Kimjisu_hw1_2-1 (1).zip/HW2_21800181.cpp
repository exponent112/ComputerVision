// 21800181 Kimjisu
// Date : 2021.09.13

#include "opencv2/opencv.hpp"
#include <iostream>
#include <cstdio>

using namespace std;
using namespace cv;

//Negative transformation
//Log transformation
//  Use log(mat a) function to perform log operation
//  To use log function, pixel type of input should be floating point
//  Also use normalize(img, img, 0, 255, NORM_MINMAX)
//Gamma transformation with gamma as 0.5
//  Make sure you normalize pixel values from 0 to 1.0
int main(){
    Mat img;
    Mat negative_img, log_float,log_img,gamma_img;
    double c = 1.5f;

    img = imread("Lena.png",0);
    negative_img = img.clone();
    //negative
    for(int i = 0;i <img.rows;i++)
        for(int j = 0; j<img.cols;j++)
            negative_img.at<uchar>(i,j) = 255 - negative_img.at<uchar>(i,j);
    //log
    img.convertTo(log_float, CV_32F);
    log_float = abs(log_float)+1;
    log(log_float,log_float);
    normalize(log_float, log_float, 0, 255, NORM_MINMAX);
    convertScaleAbs(log_float, log_img,c,0);
    //gamma
    float gamma = 0.5;
    gamma_img = img.clone();

    for(int i = 0;i <img.rows;i++)
        for(int j = 0; j<img.cols;j++)
            gamma_img.at<uchar>(i,j) = pow((float)(gamma_img.at<uchar>(i,j) / 255.0), gamma) * 255.0f;
    
    convertScaleAbs(gamma_img, gamma_img, 1,0);
        
    imshow("img",img);
    imshow("negative_img", negative_img);
    imshow("log_img", log_img);
    imshow("gamma_img", gamma_img);
    
    waitKey();
}
