// 21800181 Kimjisu
// Date : 2021.09.13

#include "opencv2/opencv.hpp"
#include <iostream>
#include <cstdio>

using namespace std;
using namespace cv;


int main() {
    Mat frame;
    VideoCapture cap;
    
    if (cap.open("background.mp4") == 0) {
        cout << "no such file!" << endl;
        waitKey(0);
    }
    
    double fps = cap.get(CAP_PROP_FPS);
    int total_frames = cap.get(CAP_PROP_FRAME_COUNT);
    int currentFrame = 0;
    while (1) {
        double time_in_msec = cap.get(CAP_PROP_POS_MSEC);
        if(time_in_msec==3000) break;
        cap >> frame;
        currentFrame++;
        if (frame.empty()) {
            break;
        }
        imshow("video", frame);
        waitKey(1000/fps);
        cout<<"frames: "<<currentFrame<<"/"<<total_frames<<endl;
    }
}